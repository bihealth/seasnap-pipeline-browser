## prepare contrasts for the gene browser, adding action button, sorting,
## removing unnecessary columns etc.
.gene_browser_prep_res <- function(cntr, but, annot, annot_linkout, primary_id) {

	names(cntr_ids) <- cntr_ids <- names(cntr)

  cntr <- map(cntr_ids, ~
              .gene_browser_prep_res_single(
                                            .x,
                                            cntr[[.x]],
                                            but,
                                            annot[[.x]],
                                            annot_linkout[[.x]],
                                            primary_id))
  return(cntr) 
}

## this function runs the preparation for a single dataset
.gene_browser_prep_res_single <- function(ds_id, cntr, but, annot, annot_linkout, primary_id) {
  cntr   <- cntr %>% 
    map(~ { .x %>% mutate('>'= sprintf(but, ds_id, .data[[primary_id]])) }) %>%
    map(~ { .x %>% select(all_of(setdiff(colnames(.x), c("stat", "lfcSE", "symbol", "entrez")))) }) %>%
    map(~ { .x %>% { merge(annot, ., by=primary_id, all.x=TRUE) } %>% 
        relocate(all_of(">"), .before=1) %>% arrange(pvalue)})

  if(!is.null(annot_linkout)) {
    cntr <- map(cntr, ~ {
                         for(n in names(annot_linkout)) {
                           fmt <- sprintf('<a href="%s" target="_blank">%%s</a>', annot_linkout[[n]])
                           .x[[n]] <- ifelse(
                                             is.na(.x[[n]]) | .x[[n]] == "", 
                                             .x[[n]], 
                                             sprintf(fmt, .x[[n]], .x[[n]]))
                         }
                         .x
    })
  }

  return(cntr)
}

## Wrapper around plot_gene, mainly to replace "N/A" with NA
.gene_browser_plot <- function(covar, id, covarName, rld, annot, 
                               groupBy = "N/A", colorBy = "N/A", symbolBy = "N/A", trellisBy="N/A") {
  .args <- list(id=id, xCovar=covarName, covar=covar, exprs=rld, groupBy=groupBy, annot=annot,
                colorBy=colorBy, symbolBy=symbolBy, trellisBy=trellisBy)
  ## weirdly, the line below is really, really slow
  #.args <- map(.args, ~ if(!is.na(.x) && .x == "N/A") { NA } else { .x })
  if(.args$groupBy == "N/A") .args$groupBy <- NA
  if(.args$colorBy == "N/A") .args$colorBy <- NA
  if(.args$symbolBy == "N/A") .args$symbolBy <- NA
  if(.args$trellisBy == "N/A") .args$trellisBy <- NA
  #plot_gene(pip, id, xCovar=covarName, covar=covar, rld=rld, groupBy=groupBy, colorBy=colorBy, symbolBy=symbolBy)
  do.call(plot_gene_generic, .args)
}

.default_covar <- function(covar, all_covars, default="group") {
  interesting_covars <- covar %>% 
      summary_colorDF() %>% 
      filter(unique < n()) %>% 
      pull(.data$Col)

  if(default %in% interesting_covars) {
    default_covar <- default
  } else {
    if(length(interesting_covars) > 0) {
      default_covar <- interesting_covars[1]
    } else {
      default_covar <- all_covars[1]
    }
  }

  return(default_covar)
}

## prepare the additional gene info tab panel
.gene_browser_info_tab <- function(id, x, y, covar) {
     ret <- ""

     if(is.numeric(x)) {
       pearson.test  <- cor.test(x, y, use="p")
       spearman.test <- cor.test(x, y, use="p", method="s")
       ret <- paste0(ret,
         sprintf("Correlation: r=%.2f [p = %s], rho=%.2f [p = %s]",
                 pearson.test$estimate,
                 format.pval(pearson.test$p.value, digits=2),
                 spearman.test$estimate,
                 format.pval(spearman.test$p.value, digits=2)))
     }
     return(ret)
}

.prep_cntr_titles <- function(cntr_titles) {

  if(is.list(cntr_titles)) {
    cntr_titles <- imap(cntr_titles, ~ {
                        ret <- paste0(.y, '::', .x)
                        #names(ret) <- paste0(.y, ": ", names(.x))
                        names(ret) <- names(.x)
                        ret
         })
    if(length(cntr_titles) < 2) {
      cntr_titles <- cntr_titles[[1]]
    }
  } else {
    tmp <- cntr_titles
    cntr_titles <- paste0("default::", tmp)
    names(cntr_titles) <- names(tmp)
  }

  return(cntr_titles)
}

#' @rdname geneBrowserTableServer
#' @export
geneBrowserTableUI <- function(id, cntr_titles) {

  cntr_titles <- .prep_cntr_titles(cntr_titles)
  but <- actionButton("foo", label=" \U25B6 ", class = "btn-primary btn-sm")
  sidebarLayout(
    sidebarPanel(
        fluidRow(selectInput(NS(id, "contrast"), label = "Contrast", choices = cntr_titles, width="100%")),
        fluidRow(
                 column(6,
                 checkboxInput(NS(id, "filter"), "Filter", TRUE, width="100%"),
                 numericInput(NS(id, "f_lfc"),    label="Filter by abs(LFC)", min=0, value=0.5, step=.1, width="100%"),
                 numericInput(NS(id, "f_pval"),    label="Filter by FDR", min=0, max=1.0, value=0.05, step=.1, width="100%")), column(6,
                 selectInput(NS(id, "f_dir"), label="Direction", choices=c(Any="an", Up="up", "Down"="dw"), 
                             width="100%")
                 )),
      tagList(
        HTML(paste("Click on the", but, "buttons to view an expression profile<br/>"))
      ),
      width=3
    ),
    mainPanel(
      withSpinner(dataTableOutput(NS(id, "result_tbl"))),
      width=9
    )
  )
}

## check whether data is list of lists or just a list of dfs
.check_multilevel <- function(cntr) {

  !any(map_lgl(cntr, is.data.frame)) 

}

.check_params <- function(multilevel, annot=NULL, cntr=NULL, annot_linkout=NULL, primary_id="PrimaryID") {

  if(!is.null(cntr)) {
    stopifnot(!is.null(names(cntr)))

    if(multilevel) {
      for(c in names(cntr)) {
        stopifnot(all(map_lgl(cntr[[c]], is.data.frame)))
      }
    }
  }

  if(!is.null(annot)) {
    if(multilevel) {
      stopifnot(all(map_lgl(annot, is.data.frame)))
      stopifnot(all(map_lgl(annot, ~ primary_id %in% colnames(.x))))
    } else {
      stopifnot(is.data.frame(annot))
      stopifnot(primary_id %in% colnames(annot))
    }
  }

  if(!is.null(annot) && !is.null(cntr)) {
    if(multilevel) {
      stopifnot(!is.null(names(annot)))
      stopifnot(all(names(cntr) %in% names(annot)))
    }
  }
}


#' Shiny Module – gene browser table selection
#'
#' Shiny Module – gene browser table selection
#'
#' The basic data set structure that this module takes is a named list of data
#' frames. These data frames will be shown in the browser when the specific
#' contrast (corresponding to a name in the list) is selected from the
#' configuration sidebar. The data frames *must* contain a column called
#' "PrimaryID" (this identifier can be changed with the parameter
#' `primary_id`). This is necessary in order to link the table rows with
#' e.g. plotting genes with `geneBrowserPlotServer`.
#'
#' Log2 fold changes must be stored in a column called
#' "log2FoldChange", and p-values in a column called "padj". These are the
#' default column names returned by DESeq2.
#'
#' Alternatively, tmodBrowserTableServer takes a list of lists of data
#' frames; that is, it allows to group the results of differential gene
#' analysis.
#'
#' The linkout feature (parameter `annot_linkout`) allows to define how the
#' different columns from the annotation data frame are represented as
#' linkouts to external data bases. 
#'
#' The parameter `annot_linkout` is a named list. Names must correspond to
#' columns from the annotation data frame. The elements of the list are
#' character strings containing URLs with the `%s` placeholder. For
#' example, if the column `ENSEMBL` contains ENSEMBL identifiers, you can
#' link out by specifying 
#'
#' ```
#' annot_linkout=list(ENSEMBL="https://www.ensembl.org/id/%s")
#' ```
#' @param cntr a list of data frames containing the DE analysis results, or
#'             a list of lists of data frames
#' @param annot annotation data frame containing column 'PrimaryID' (
#'        or another specified by the parameter `primary_id`)
#'        corresponding to the rownames of the contrast data frames
#' @param id identifier for the namespace of the module
#' @param primary_id name of the column which holds the primary identifiers
#' @param cntr_titles named character vector for contrast choices
#' @param annot_linkout a list; see Details. 
#' @return reactive value containing the gene ID
#' @export
geneBrowserTableServer <- function(id, cntr, annot, annot_linkout=NULL,
                                   primary_id="PrimaryID") {

  multilevel <- .check_multilevel(cntr)
  .check_params(multilevel, cntr=cntr, annot=annot, 
                annot_linkout=annot_linkout, primary_id=primary_id)

  if(!multilevel) {
    cntr <- list(default=cntr)
    annot <- list(default=annot)
    annot_linkout=list(default=annot_linkout)
  }

  moduleServer(id, function(input, output, session) {

    gene_id <- reactiveVal(list(ds=NA, id=NA))

    but <- actionButton("go~%s~%s", label=" \U25B6 ", 
                         onclick=sprintf('Shiny.onInputChange(\"%s-select_button\",  this.id)', id),  
                         class = "btn-primary btn-sm")

    cntr <- .gene_browser_prep_res(cntr, as.character(but), annot, 
                                   annot_linkout, primary_id=primary_id)

    observeEvent(input$select_button, {
      .ids <- strsplit(input$select_button, '~')[[1]]
      gene_id(list(ds=.ids[2], id=.ids[3]))
    })

    observeEvent(input$filter, {
                   if(length(input$filter) > 0 && input$filter) {
                     enable("f_dir")
                     enable("f_pval")
                     enable("f_lfc")
                   } else {
                     disable("f_dir")
                     disable("f_pval")
                     disable("f_lfc")
                   }
    })

    output$id_summary <- renderText({
      .cntr <- input$contrast
      sprintf("Contrast is %s", .cntr)
    })

    output$result_tbl <- DT::renderDataTable({

      .cntr <- gsub(".*::", "", input$contrast)
      .ds   <- gsub("::.*", "", input$contrast)

      res <- cntr[[ .ds ]][[ .cntr ]]
      if(input$filter) {
        if(input$f_dir == "up") {
          res <- res %>% filter(.data[["log2FoldChange"]] > 0)
        } else if(input$f_dir == "dw") {
          res <- res %>% filter(.data[["log2FoldChange"]] < 0)
        }

        res <- res %>% filter(.data[["padj"]] < input$f_pval & abs(.data[["log2FoldChange"]]) > input$f_lfc) 
      }

      res %>% datatable(escape=FALSE, selection='none', extensions="Buttons",
                options=list(pageLength=5, dom="Bfrtip", scrollX=TRUE, buttons=c("copy", "csv", "excel"))) %>%
        formatSignif(columns=intersect(colnames(res), 
                                       c("baseMean", "log2FoldChange", "pvalue", "padj")), digits=2)
    })

    gene_id
  })
}

.dynamic_col_control <- function(id, covar) {


  all_covars         <- covar %>% summary_colorDF() %>% filter(unique > 1) %>% pull(.data$Col)
  non_unique         <- covar %>% summary_colorDF() %>% filter(unique < nrow(covar)) %>% pull(.data$Col)
  default_covar <- .default_covar(covar, all_covars, default="group")

  tagList(
      fluidRow(downloadButton(NS(id, "save"), "Save plot to PDF", class="bg-success")),
      fluidRow(
      column(width=5, 
      fluidRow(selectInput(NS(id, "covarName"), "X covariate", non_unique, selected=default_covar, width="100%")),
      fluidRow(selectInput(NS(id, "colorBy"), "Color by", c("N/A", non_unique), selected="N/A", width="100%")),
      fluidRow(selectInput(NS(id, "symbolBy"), "Symbol by", c("N/A", non_unique), selected="N/A", width="100%")),
      ),
      column(width=5,
      fluidRow(selectInput(NS(id, "groupBy"), "Link data points by", c("N/A", non_unique), selected="N/A", width="100%")),
      fluidRow(selectInput(NS(id, "trellisBy"), "Trellis by", c("N/A", non_unique), selected="N/A", width="100%")),
      fluidRow(numericInput(NS(id, "fontSize"),    label="Font size", min=6, value=14, step=1, width="50%")),
      offset=1)
      ),
      fluidRow(textOutput(NS(id, "addInfo"))),
      fluidRow(verbatimTextOutput(NS(id, "geneData")))
    )


}

#' @rdname geneBrowserPlotServer
#' @export
geneBrowserPlotUI <- function(id, contrasts=FALSE) {
  col_control <- 
    sidebarPanel(
                 uiOutput(NS(id, "col_control"))
                 )

  if(contrasts) {
    return(sidebarLayout(col_control,
      mainPanel(
      column(9, style="padding:20px;", tabsetPanel(
      tabPanel("Plot", fluidRow(br(), plotOutput(NS(id, "countsplot")))),
      tabPanel("Contrast overview", fluidRow(br(), dataTableOutput(NS(id, "contr_sum"))))
      )))))
  } else {
    return(col_control,
      mainPanel(withSpinner(plotOutput(NS(id, "countsplot")))))
  }

}

#' Shiny Module – gene browser expression profile plot
#'
#' Shiny Module – gene browser expression profile plot
#'
#' The `gene_id` parameter must be a reactive value, because that is the
#' whole point of the plotting module: observe changes to the gene ID and
#' update the plot accordingly.
#' 
#' In contrast, other parameters must not be reactive values. This may
#' change in future to allow for dynamic exchange of data sets.
#' @param gene_id primary identifier of the gene to show. This must be a
#'        reactive value
#' @param primary_id name of the column which holds the primary identifiers
#' @param exprs expression matrix; row names must correspond to the primary identifiers
#' @param contrasts (logical) whether or not create an additional panel
#'        next to the plot which can be used to show detailed contrast
#'        information for a gene
#' @param annot (optional) annotation data frame containing column 'PrimaryID'
#'        corresponding to the rownames of the contrast data frames
#' @param id identifier (same as the one passed to geneBrowserTableUI)
#' @param covar data frame with all covariates
#' @param cntr (optional) list of contrasts
#' @param symbol_col name of the column in `annot` which contains the gene
#'        symbols; use NULL if no such column
#' @param description_col name of the column in `annot` which contains the gene
#'        title / description; use NULL if no such column
#' @return does not return anything useful
#' @examples
#' if(interactive()) {
#'    mtx <- matrix(rnorm(40, mean=rep(c(0, 1), each=20)), nrow=1)
#'    rownames(mtx) <- "MUZG"
#'    covar <- data.frame(
#'                        em=rep(LETTERS[1:2], each=20),
#'                        pstrem=rep(letters[1:20], 2),
#'                        bzdrem=rnorm(40))
#'   
#'    ui  <- fluidPage(geneBrowserPlotUI("gplot", covar))
#'    serv <- function(input, output, session) {
#'      gid <- reactiveVal()
#'      gid("MUZG")
#'      geneBrowserPlotServer("gplot", gid, covar, mtx)
#'    }
#'    shinyApp(ui, serv)
#' }
#' @export
geneBrowserPlotServer <- function(id, gene_id, covar, exprs, annot=NULL, cntr=NULL, 
                                  primary_id="PrimaryID", symbol_col="SYMBOL", description_col="GENENAME") {
## XXX make checks
# stopifnot(is.reactive(gene_id))
# stopifnot(!is.reactive(covar))
# stopifnot(!is.reactive(exprs))
# stopifnot(!is.reactive(annot))
# stopifnot(is.null(annot) || is.data.frame(annot))
# if(!is.null(annot)) {
#   stopifnot(all(c(primary_id, symbol_col, description_col) %in% 
#                 colnames(annot)))
# }

  if(is.data.frame(covar)) {
    covar <- list(default=covar)
    exprs <- list(default=exprs)
    annot <- list(default=annot)
    cntr  <- list(default=cntr)
  }


  moduleServer(id, function(input, output, session) {
    disable("save")

    ds   <- reactiveVal()
    g_id <- reactiveVal()

    observe({
      ds(gene_id()$ds)
      g_id(gene_id()$id)
    })

    ## Save figure as a PDF
    output$save <- downloadHandler(
      filename = function() {
        .id <- g_id()
        .ds <- ds()
        ret <- sprintf("expression_profile_ds_%s_%s_covarX_%s_colorBy_%s_groupBy_%s_symbolBy_%s_trellisBy_%s.pdf",
                       .ds, .id,
                       input$covarName, input$colorBy, input$groupBy, input$symbolBy, input$trellisBy)
        ret <- gsub("[^0-9a-zA-Z_.-]", "", ret)
        return(ret)
      },
      content = function(file) {
        pdf(file=file, width=8, height=5)
        g <- .gene_browser_plot(covar[[ ds() ]], g_id(), 
                                input$covarName, 
                                exprs[[ ds() ]], 
                                annot[[ ds() ]], 
                           input$groupBy, input$colorBy, input$symbolBy, input$trellisBy)
        print(g)
        dev.off()
      }
    )

    # Show a turbo card for a gene
    output$geneData <- renderText({

      ret <- sprintf("%s: %s", primary_id, g_id())
      if(!is.null(annot[[ ds() ]])) {

        m <- match(g_id(), annot[[  ds()  ]][[ primary_id ]])

        if(!is.null(symbol_col)) {
          ret <- paste0(ret,
                       sprintf("\nSymbol: %s",
                               annot[[  ds()  ]][m, ][[symbol_col]])) 
        }
        if(!is.null(description_col)) {
          ret <- paste0(ret, 
                        sprintf("\nDescription: %s",
                                annot[[  ds()  ]][m, ][[description_col]]))
        }
      }
      return(ret)
    })

    ## summary contrasts table
    observe({
      if(!is.null(cntr[[ ds() ]])) {
        output$contr_sum <- DT::renderDataTable({
          cn <- names(cntr[[ ds() ]])
          res <- imap_dfr(cntr[[ ds() ]], ~ .x %>% 
                          filter(.data[[ primary_id ]] == g_id()) %>% 
                      mutate(contrast=.y))
          res <- imap_dfr(cntr, ~ {
                            .ds <- .y
                            imap_dfr(.x, ~ {
                                       .x %>% filter(.data[[ primary_id ]] == g_id()) %>%
                                         mutate("Data set"=.ds, Contrast=.y)
                            })
                      })

          numcol <- map_lgl(res, is.numeric)
          res %>% datatable(escape=FALSE, selection='none', options=list(pageLength=5)) %>%
            formatSignif(columns=colnames(res)[numcol], digits=2)
        })
    }})

    ## Additional information - e.g. correlation coefficient if the
    ## covariate is numeric
    output$addInfo <- renderText({
      .gene_browser_info_tab(g_id(), covar[[g_id()]][[input$covarName]], exprs[[ds()]][ g_id(), ])
    })

    ## reload the plot interface only if the data set (and covariates)
    ## changed
    output$col_control <- renderUI({
      .ds <- ds()
      if(!isTruthy(.ds)) { .ds <- 1 }
      .dynamic_col_control(id, covar[[.ds]])
    })

    ## The actual plot
    output$countsplot <- renderPlot({
      if(is.na(g_id())) { return(NULL) }
      enable("save")
      
      .gene_browser_plot(covar[[ds()]], g_id(), input$covarName, exprs[[ ds() ]], annot[[ ds() ]], 
                         input$groupBy, input$colorBy, input$symbolBy, input$trellisBy) +
                                    theme(text=element_text(size=input$fontSize))
    })
  })
}


#' Launch a browser of DE analysis results
#'
#' Launch a shiny-based browser of DE analysis results
#'
#' Launches a shiny app, web based, which allows to show gene expression
#' profiles in a pipeline. 
#'
#' To speed up launching, you can pre-load the contrasts with the
#' `get_contrasts` function.
#' @param pip pipeline object returned by `load_de_pipeline`
#' @param cntr (optional) pre-loaded contrasts (returned by `get_contrasts`)
#' @param annot (optional) pre-loaded annotation table (returned by `get_annot`)
#' @return does not return a value
#' @importFrom rlang .data
#' @importFrom stats cor.test
#' @importFrom bslib bs_theme
#' @examples
#' \dontrun{
#' pip <- load_de_pipeline(config_file="DE_config.yaml")
#' gene_browser(pip, tmod_dbs)
#' }
#' @export
gene_browser <- function(pip, cntr=NULL, annot=NULL) {

  message("preparing...")
  if(is.null(annot)) {
    message(" * Loading Annotation (consider using the annot option to speed this up)")
    annot  <- get_annot(pip)
  }

  # prepare the contrast tables
  if(is.null(cntr)) {
    message(" * Loading contrasts... (consider using the cntr option to speed this up)")
    cntr <- get_contrasts(pip)
  }

  config <- get_config(pip)
  covar  <- get_covariates(pip)

  rld    <- get_object(pip, step="DESeq2", extension="rld.blind.rds")
  rld    <- rld@assays@data@listData[[1]]
  
  cntr_titles <- map_chr(config$contrasts$contrast_list, `[[`, "ID")
  names(cntr_titles) <- map_chr(config$contrasts$contrast_list, `[[`, "title")

  thematic_shiny(font="auto")

  ## prepare the UI
  ui <- fluidPage(
    useShinyjs(),
    theme = bs_theme(bootswatch = "united"),
    fluidRow(titlePanel(h1("Gene browser")), class="bg-primary"),
    fluidRow(HTML("<hr>")),
    geneBrowserTableUI("geneTab", cntr_titles),
    geneBrowserPlotUI("genePlot", contrasts=TRUE)
  )

  ## prepare the server
  server <- function(input, output, session) {
    gene_id <- geneBrowserTableServer("geneTab", cntr, annot)
    geneBrowserPlotServer("genePlot", gene_id, covar, rld, annot)

    message("launching!")
  }

  shinyApp(ui, server)
}

