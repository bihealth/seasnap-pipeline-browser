## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
# Minimal example included in the package
library(Rseasnap)
example_pipeline_file <- file.path(
  system.file("extdata", package="Rseasnap"),
  "example_pipeline",
  "DE_config.yaml")
pip <- load_de_pipeline(config_file=example_pipeline_file)

# get the DESeq2 object
ds <- get_deseq2(pip)

# get the file tab
file_tab <- get_file_tab(pip)

# plot expression of a gene

# launch the browser
if(interactive()) {
  pipeline_browser(pip)
}

## ----eval=FALSE---------------------------------------------------------------
#  library(Rseasnap)
#  pip <- load_de_pipeline(config_file="DE_config.yaml")

## ----eval=FALSE---------------------------------------------------------------
#  file_tab <- get_file_tab(pip)
#  ds2      <- get_deseq2(pip)
#  cntr     <- get_contrasts(pip)
#  cntr_ids <- get_contrast_names(pip)
#  covar    <- get_covariates(pip)
#  config   <- get_config(pip)
#  annot    <- get_annot(pip)
#  tmod     <- get_tmod_res(pip)
#  tmod_dbs <- get_tmod_dbs(pip)
#  tmod_map <- get_tmod_mapping(pip)

## ----eval=FALSE---------------------------------------------------------------
#  obj <- get_object(pip, step="DESeq2", extension="rld.blind.rds")

## ----eval=FALSE---------------------------------------------------------------
#  tmod_dbs <- get_tmod_dbs(pip)
#  pipeline_browser(pip, tmod_dbs=tmod_dbs)

## ---- fig.width=8,fig.height=4------------------------------------------------
library(cowplot)
library(ggplot2)
theme_set(theme_bw())
g1 <- plot_gene(pip, "ENSG00000131747", "group.icu")
g2 <- plot_gene(pip, "ENSG00000131747", "fibrinogen",
  colorBy="group", symbolBy="icu")
plot_grid(g1, g2)

## ----fig.width=4,fig.height=4-------------------------------------------------
g1$layers[[2]]$aes_params$size <- 1
g1

## ----fig.width=6,fig.height=4-------------------------------------------------
plot_evidence(pip, id="LI.M4.2", dbname="tmod", contrast="COVID19_ID0")

## ----fig.width=10,fig.height=5------------------------------------------------
cntr <- get_contrasts(pip)
g1 <- plot_disco(cntr[[1]], cntr[[2]])
g2 <- plot_disco(cntr[[1]], cntr[[2]], lower=-5, upper=5)
plot_grid(g1, g2)

## -----------------------------------------------------------------------------
tmod_dbs <- get_tmod_dbs(pip)
disco <- disco_score(cntr[[1]], cntr[[2]])
ord <- order(disco$disco, decreasing=TRUE)
gene_list <- disco$PrimaryID[ ord ]
test_gsea_tmod(pip, gene_list, "tmod")

## ----eval=FALSE---------------------------------------------------------------
#  pipeline_browser(pip)

## ----eval=FALSE---------------------------------------------------------------
#  library(shiny)
#  cntr  <- get_contrasts(pip)
#  annot <- get_annot(pip)
#  
#  ui <- fluidPage(
#    geneBrowserTableUI("geneT", names(cntr))
#    )
#  
#  server <- function(input, output, session) {
#    geneBrowserTableServer("geneT", cntr, annot)
#  }
#  
#  shinyApp(ui, server)

